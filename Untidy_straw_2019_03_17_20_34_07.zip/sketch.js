function setup() {
  createCanvas(400, 400);
  print("Hello");
}

function draw() {
  background(100);
  noStroke();
  fill(0,0,255,50);
  circle(200,100,90);
  fill(255,0,0,50);
  circle(125,210,90);
  fill(0,255,0,50);
  circle(275,210,90);
}